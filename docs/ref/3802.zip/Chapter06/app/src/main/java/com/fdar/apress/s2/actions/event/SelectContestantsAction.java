package com.fdar.apress.s2.actions.event;

import org.apache.struts2.config.ParentPackage;

import java.util.List;
import java.util.ArrayList;

@ParentPackage("enterEvent")
public class SelectContestantsAction extends BaseEventAction {

    public String execute() throws Exception {
        return INPUT;
    }
}
