package com.fdar.apress.s2.services;

import com.fdar.apress.s2.domain.Event;

public interface EventService {

    public void create(Event event);
}
