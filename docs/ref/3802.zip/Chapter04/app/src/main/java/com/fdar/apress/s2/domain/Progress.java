package com.fdar.apress.s2.domain;

public enum Progress {
    NOT_STARTED,
    IN_PROGRESS,
    COMPLETED,
    VOTING_CLOSED,
    CLOSED
}
