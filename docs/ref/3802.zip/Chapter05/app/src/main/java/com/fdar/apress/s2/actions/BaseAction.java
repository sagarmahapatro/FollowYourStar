/**
 * Copyright:	Copyright (c) From Down & Around, Inc.
 */

package com.fdar.apress.s2.actions;

import com.opensymphony.xwork2.ActionSupport;

/**
 * @author Ian Roughley
 * @version $Id$
 */
public class BaseAction extends ActionSupport {
}
