/**
 * Copyright:	Copyright (c) From Down & Around, Inc.
 */

package com.fdar.apress.s2;

import org.apache.struts2.config.Results;
import org.apache.struts2.config.Result;
import org.apache.struts2.dispatcher.ServletDispatcherResult;

import java.util.Random;

public class ZC4Action {

    public String execute() throws Exception {
        throw new Exception();
//        return "success";
    }
}
